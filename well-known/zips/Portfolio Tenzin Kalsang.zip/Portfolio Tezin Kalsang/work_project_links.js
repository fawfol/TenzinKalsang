function hangman_link(){
    window.open('hangman-index.html', '_blank', 'noopener,noreferrer');
}
function tictactoe_link(){
    window.open('TicTacToe.html', '_blank', 'noopener,noreferrer');
}
function rpg_link(){
    window.open('rpg-game-index.html', '_blank', 'noopener,noreferrer');
}