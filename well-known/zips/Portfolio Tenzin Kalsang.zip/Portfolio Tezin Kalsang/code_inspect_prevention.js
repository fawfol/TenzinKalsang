document.addEventListener("contextmenu", function(e){
    e.preventDefault();
});
        //disable DevTools
        console.log("%cWarning: DevTools are not allowed!", "font-size: 100px; color: red;");
        // ...